<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    die("Akses ditolak.");
}
require_once '../includes/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['status'];

    // Validasi status untuk keamanan
    $allowed_statuses = ['pending', 'confirmed', 'completed', 'canceled'];
    if (in_array($new_status, $allowed_statuses)) {
        $sql = "UPDATE pre_orders SET status = ? WHERE id = ?";
        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, "si", $new_status, $order_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

header("Location: admin_po_masuk.php?status_update=sukses");
exit;
?>