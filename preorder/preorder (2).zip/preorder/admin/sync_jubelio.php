<?php 
require_once '../includes/header.php'; 
?>

<style>
    .pesan { padding: 15px; margin-bottom: 20px; border-radius: 5px; border: 1px solid transparent; }
    .pesan.sukses { background-color: #d4edda; color: #155724; border-color: #c3e6cb; }
    .pesan.gagal { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb; }
    .pesan.warning { background-color: #fff3cd; color: #856404; border-color: #ffeeba; }
    .pesan.info { background-color: #d1ecf1; color: #0c5460; border-color: #bee5eb; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: auto; }
</style>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<div class="content-box">
    <h1>Pilih SKU Varian untuk Diimpor</h1>
    
    <div id="notification-area"></div>

    <div id="product-container">
        <div id="loading-spinner" style="text-align: center; padding: 50px;">
            <div class="spinner"></div>
            <p>Mengambil data dari Jubelio, mohon tunggu...</p>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let jubelioDataTable; 

    function loadProducts() {
        $('#product-container').html('<div id="loading-spinner" style="text-align: center; padding: 50px;"><div class="spinner"></div><p>Mengambil data...</p></div>');
        
        fetch('fetch_jubelio_products.php')
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw new Error(err.error || 'Network response was not ok'); });
                }
                return response.json();
            })
            .then(data => {
                let tableHTML = `
                    <form id="import-form">
                        <table id="produk-jubelio-table" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="selectAll"></th>
                                    <th>Nama Produk (Varian)</th>
                                    <th>SKU (Item Code)</th>
                                    <th>Harga Jual</th>
                                    <th>Tanggal di Jubelio</th>
                                </tr>
                            </thead>
                            <tbody>`;
                data.forEach(product_group => {
                    if (product_group.variants && Array.isArray(product_group.variants)) {
                        product_group.variants.forEach(variant => {
                            let variant_name = variant.item_name || 'N/A';
                            let variant_details = [];
                            if (variant.variation_values && Array.isArray(variant.variation_values)) {
                                variant.variation_values.forEach(variation => { variant_details.push(variation.value); });
                            }
                            if (variant_details.length > 0) {
                                variant_name += ' (' + variant_details.join(', ') + ')';
                            }
                            const product_data = JSON.stringify({
                                sku: variant.item_code,
                                price: variant.sell_price,
                                name: variant_name,
                                jubelio_date: product_group.last_modified
                            }).replace(/'/g, "&apos;");
                            const formattedPrice = new Intl.NumberFormat('id-ID').format(variant.sell_price || 0);
                            const date = new Date(product_group.last_modified);
                            const formattedDate = date.toLocaleString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                            const rawTimestamp = date.getTime() / 1000;
                            tableHTML += `
                                <tr>
                                    <td style="text-align: center;"><input type="checkbox" name="selected_products[]" value='${product_data}'></td>
                                    <td>${variant_name}</td>
                                    <td>${variant.item_code}</td>
                                    <td data-order="${variant.sell_price || 0}">Rp ${formattedPrice}</td>
                                    <td data-order="${rawTimestamp}">${formattedDate}</td>
                                </tr>`;
                        });
                    }
                });
                tableHTML += `</tbody></table><button type="submit" style="background-color: #28a745; color: white; padding: 10px 20px; border: none; font-size: 16px; cursor: pointer; border-radius: 5px; margin-top: 20px;">Impor Produk Terpilih</button></form>`;
                
                $('#product-container').html(tableHTML);
                jubelioDataTable = $('#produk-jubelio-table').DataTable({ "language": { "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json" }});
                
                $('#selectAll').on('click', function(){
                    var rows = jubelioDataTable.rows({ 'search': 'applied' }).nodes();
                    $('input[type="checkbox"]', rows).prop('checked', this.checked);
                });

                $('#import-form').on('submit', function(e) {
                    e.preventDefault();
                    const formData = $(this).serialize();
                    const importBtn = $(this).find('button[type="submit"]');
                    const notifArea = $('#notification-area');
                    
                    importBtn.prop('disabled', true).text('Mengimpor...');
                    notifArea.html('');

                    $.ajax({
                        url: 'proses_sync.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            let notifClass = response.type || 'info';
                            notifArea.html(`<div class="pesan ${notifClass}">${response.message}</div>`);
                        },
                        error: function() {
                            notifArea.html('<div class="pesan gagal">Terjadi error saat mengirim data.</div>');
                        },
                        complete: function() {
                            importBtn.prop('disabled', false).text('Impor Produk Terpilih');
                        }
                    });
                });
            })
            .catch(error => {
                $('#product-container').html('<div class="pesan gagal">Gagal memuat data produk. Error: ' + error.message + '</div>');
            });
    }
    
    loadProducts();
});
</script>

<?php 
require_once '../includes/footer.php'; 
?>