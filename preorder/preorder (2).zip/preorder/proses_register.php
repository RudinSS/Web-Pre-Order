<?php
require_once 'includes/koneksi.php';

// Memeriksa apakah form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Mengambil data dari form
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validasi sederhana
    if (empty($full_name) || empty($username) || empty($password)) {
        header("Location: register.php?pesan=gagal");
        exit;
    }

    if (strlen($password) < 6) {
        header("Location: register.php?pesan=password_pendek");
        exit;
    }

    // 1. Cek apakah username sudah ada (SANGAT PENTING!)
    $sql_check = "SELECT id FROM users WHERE username = ?";
    if ($stmt_check = mysqli_prepare($koneksi, $sql_check)) {
        mysqli_stmt_bind_param($stmt_check, "s", $username);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) > 0) {
            // Username sudah ada, arahkan kembali dengan pesan error
            header("Location: register.php?pesan=username_sudah_ada");
            exit;
        }
        mysqli_stmt_close($stmt_check);
    }

    // 2. Hash password sebelum disimpan ke database
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // 3. Menetapkan role default
    $role = 'customer'; // Default role untuk setiap pendaftaran baru

    // 4. Menyimpan data user baru ke database
    $sql_insert = "INSERT INTO users (full_name, username, password, role) VALUES (?, ?, ?, ?)";
    
    if ($stmt_insert = mysqli_prepare($koneksi, $sql_insert)) {
        // Mengikat parameter
        mysqli_stmt_bind_param($stmt_insert, "ssss", $full_name, $username, $hashed_password, $role);
        
        // Menjalankan statement
        if (mysqli_stmt_execute($stmt_insert)) {
            // Jika berhasil, arahkan ke halaman login dengan pesan sukses
            header("Location: index.php?pesan=registrasi_sukses");
            exit;
        }
    }

    // Jika terjadi error selama proses insert
    header("Location: register.php?pesan=gagal");
    exit;

} else {
    // Jika file diakses langsung, kembalikan ke halaman registrasi
    header("Location: register.php");
    exit;
}
?>