<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/koneksi.php';

$aksi = $_POST['aksi'] ?? $_GET['aksi'] ?? '';

// Logika untuk Tambah Produk (dari form edit, tidak digunakan lagi tapi aman untuk ada)
if ($aksi == 'tambah') {
    $sku = $_POST['sku'];
    $brand_id = $_POST['brand_id'];
    $base_price = $_POST['base_price'];
    $model_name = $sku;

    $sql = "INSERT INTO products (brand_id, model_name, sku, base_price) VALUES (?, ?, ?, ?)";
    if ($stmt = mysqli_prepare($koneksi, $sql)) {
        mysqli_stmt_bind_param($stmt, "issd", $brand_id, $model_name, $sku, $base_price);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}
// Logika untuk Tambah Produk Massal
elseif ($aksi == 'tambah_massal') {
    $skus = $_POST['sku'];
    $brand_ids = $_POST['brand_id'];
    $base_prices = $_POST['base_price'];

    $sukses_count = 0;
    $exist_count = 0;
    $gagal_count = 0;

    $sql_check = "SELECT sku FROM products WHERE sku = ?";
    $stmt_check = mysqli_prepare($koneksi, $sql_check);

    $sql_insert = "INSERT INTO products (brand_id, model_name, sku, base_price) VALUES (?, ?, ?, ?)";
    $stmt_insert = mysqli_prepare($koneksi, $sql_insert);

    for ($i = 0; $i < count($skus); $i++) {
        if (!empty($skus[$i])) {
            $current_sku = $skus[$i];
            
            mysqli_stmt_bind_param($stmt_check, "s", $current_sku);
            mysqli_stmt_execute($stmt_check);
            mysqli_stmt_store_result($stmt_check);
            
            if (mysqli_stmt_num_rows($stmt_check) > 0) {
                $exist_count++;
            } else {
                $model_name = $current_sku;
                mysqli_stmt_bind_param($stmt_insert, "issd", $brand_ids[$i], $model_name, $current_sku, $base_prices[$i]);
                if (mysqli_stmt_execute($stmt_insert)) {
                    $sukses_count++;
                } else {
                    $gagal_count++;
                }
            }
        }
    }
    mysqli_stmt_close($stmt_check);
    mysqli_stmt_close($stmt_insert);

    // Kirim pesan notifikasi detail ke URL
    $pesan = "Proses Selesai. Sukses: $sukses_count, Sudah Ada: $exist_count, Gagal: $gagal_count.";
    header("Location: admin_produk.php?pesan=" . urlencode($pesan));
    exit;
}
// Logika untuk Ubah Produk
elseif ($aksi == 'ubah') {
    $id = $_POST['id'];
    $sku = $_POST['sku'];
    $brand_id = $_POST['brand_id'];
    $base_price = $_POST['base_price'];
    $model_name = $sku;

    $sql = "UPDATE products SET brand_id = ?, model_name = ?, sku = ?, base_price = ? WHERE id = ?";
    if ($stmt = mysqli_prepare($koneksi, $sql)) {
        mysqli_stmt_bind_param($stmt, "issdi", $brand_id, $model_name, $sku, $base_price, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}
// Logika untuk Hapus Produk
elseif ($aksi == 'hapus') {
    $id = $_GET['id'];
    
    $sql = "DELETE FROM products WHERE id = ?";
    if ($stmt = mysqli_prepare($koneksi, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

// Redirect default
header("Location: admin_produk.php");
exit;
?>