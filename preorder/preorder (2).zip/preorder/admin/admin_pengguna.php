<?php 
require_once '../includes/header.php'; 
require_once '../includes/koneksi.php';

// Pastikan hanya admin yang bisa akses
if ($_SESSION['role'] !== 'admin') {
    die("Akses ditolak.");
}
?>

<div class="content-box">
    <h1>Manajemen Pengguna (Customer)</h1>
    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="border: 1px solid #ddd; padding: 8px;">ID</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Nama Lengkap</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Username</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Tanggal Registrasi</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Aksi</th> </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT id, full_name, username, created_at FROM users WHERE role = 'customer' ORDER BY created_at DESC";
            $result = mysqli_query($koneksi, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['id'] . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($row['full_name']) . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($row['username']) . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . date("d M Y, H:i", strtotime($row['created_at'])) . "</td>";
                    // Link Aksi Baru
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'><a href='ganti_password_user.php?id=" . $row['id'] . "'>Ganti Password</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>Belum ada customer yang terdaftar.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php 
require_once '../includes/footer.php';
?>