<?php 
require_once 'includes/header.php';
require_once 'includes/koneksi.php';
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<div class="content-box">
    <h1>Langkah 1: Pilih Produk untuk di-PO</h1>
    <p>Gunakan fitur Search dan Pagination untuk mencari produk, lalu centang produk yang ingin Anda pesan.</p>

    <form id="po-selection-form" action="rincian_po.php" method="POST">
        <table id="po-product-table" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th>Pilih</th>
                    <th>SKU</th>
                    <th>Brand</th>
                    <th>Harga</th>
                    <th>Tgl. Ditambahkan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT p.id, p.sku, p.base_price, b.brand_name, p.created_at FROM products p LEFT JOIN brands b ON p.brand_id = b.id ORDER BY p.created_at DESC";
                $result = mysqli_query($koneksi, $sql);
                while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td style="text-align: center;"><input type="checkbox" name="selected_products[]" value="<?php echo $row['id']; ?>"></td>
                        <td><?php echo htmlspecialchars($row['sku']); ?></td>
                        <td><?php echo htmlspecialchars($row['brand_name']); ?></td>
                        <td data-order="<?php echo $row['base_price']; ?>">Rp <?php echo number_format($row['base_price'], 0, ',', '.'); ?></td>
                        <td data-order="<?php echo strtotime($row['created_at']); ?>"><?php echo date("d M Y", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <button type="submit" style="background-color: #007bff; color: white; padding: 10px 20px; border: none; font-size: 16px; cursor: pointer; border-radius: 5px; margin-top: 20px;">Lanjut ke Rincian Pesanan</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        // Inisialisasi DataTables dan simpan dalam variabel
        var table = $('#po-product-table').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
            },
            "order": [[ 4, "desc" ]] 
        });

        // ---- LOGIKA BARU UNTUK MENGUMPULKAN SEMUA CHECKBOX ----
        $('#po-selection-form').on('submit', function(e){
            // 1. Hentikan pengiriman form sementara
            e.preventDefault();

            // 2. Buat kontainer sementara untuk menampung nilai checkbox
            var form = this;
            
            // Hapus input hidden sebelumnya jika ada, untuk menghindari duplikasi
            $(form).find('input[type="hidden"][name="selected_products[]"]').remove();

            // 3. Gunakan API DataTables untuk mencari SEMUA checkbox yang tercentang di SEMUA halaman
            var selected_rows = table.$('input[type="checkbox"]:checked');

            // 4. Jika tidak ada yang dipilih, tampilkan peringatan
            if(selected_rows.length === 0){
               alert('Silakan pilih minimal satu produk.');
               return false;
            }

            // 5. Loop melalui semua checkbox yang tercentang dan buat input hidden
            selected_rows.each(function(){
                $(form).append(
                    $('<input>')
                        .attr('type', 'hidden')
                        .attr('name', 'selected_products[]')
                        .val($(this).val())
                );
            });

            // 6. Sekarang, kirim form yang sudah berisi semua data yang benar
            form.submit();
        });
    });
</script>

<?php 
require_once 'includes/footer.php'; 
?>