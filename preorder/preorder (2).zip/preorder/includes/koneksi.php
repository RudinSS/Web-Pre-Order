<?php
// Pengaturan untuk koneksi database
$host       = "localhost";
$user       = "root"; // User default untuk XAMPP
$pass       = "";     // Password default untuk XAMPP (kosong)
$db_name    = "db_preorder";

// Membuat koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db_name);

// Cek koneksi
// Jika gagal, hentikan script dan tampilkan pesan error
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Jika berhasil, script akan lanjut berjalan.
// Sebaiknya tidak ada output apa pun di file ini jika koneksi berhasil.
?>