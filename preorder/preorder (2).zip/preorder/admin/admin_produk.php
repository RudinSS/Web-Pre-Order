<?php 
require_once '../includes/header.php';
require_once '../includes/koneksi.php'; 
?>

<div class="content-box">
    <h1>Manajemen Produk</h1>

    <?php if (isset($_GET['pesan'])): ?>
        <div style="padding: 15px; margin-bottom: 20px; border-radius: 5px; color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb;">
            <?php echo htmlspecialchars(urldecode($_GET['pesan'])); ?>
        </div>
    <?php endif; ?>

    <a href="form_tambah_produk.php" class="btn btn-tambah" style="background-color: #007bff; color: white; text-decoration: none; padding: 8px 15px; border-radius: 5px; display: inline-block; margin-bottom: 20px;">Tambah Produk Baru</a>
    <a href="sync_jubelio.php" class="btn" style="background-color:#17a2b8; color: white; text-decoration: none; padding: 8px 15px; border-radius: 5px; display: inline-block; margin-bottom: 20px; margin-left: 10px;">Sinkronkan dari Jubelio</a>
    
    <div style="margin-top: 20px; margin-bottom: 10px;">
        <label for="brandFilter">Filter berdasarkan Brand:</label>
        <select id="brandFilter" style="padding: 5px;">
            <option value="">Semua Brand</option>
            <?php
            $sql_brands = "SELECT brand_name FROM brands ORDER BY brand_name";
            $result_brands = mysqli_query($koneksi, $sql_brands);
            while ($row_brand = mysqli_fetch_assoc($result_brands)) {
                echo "<option value='" . htmlspecialchars($row_brand['brand_name']) . "'>" . htmlspecialchars($row_brand['brand_name']) . "</option>";
            }
            ?>
        </select>
    </div>

    <table id="manajemen-produk-table" class="display" style="width:100%;">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Brand</th>
                <th>Harga</th>
                <th>Tgl Ditambahkan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT p.id, p.sku, p.base_price, b.brand_name, p.created_at 
                    FROM products p 
                    LEFT JOIN brands b ON p.brand_id = b.id 
                    ORDER BY p.id DESC";
            $result = mysqli_query($koneksi, $sql);

            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['sku']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['brand_name']) . "</td>";
                    echo "<td data-order='" . $row['base_price'] . "'>Rp " . number_format($row['base_price'], 0, ',', '.') . "</td>";
                    echo "<td data-order='" . strtotime($row['created_at']) . "'>" . date("d M Y", strtotime($row['created_at'])) . "</td>";
                    echo "<td>";
                    echo "<a href='form_edit_produk.php?id=" . $row['id'] . "'>Edit</a> | ";
                    echo "<a href='proses_produk.php?aksi=hapus&id=" . $row['id'] . "' onclick='return confirm(\"Yakin hapus?\")'>Hapus</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function() {
    var table = $('#manajemen-produk-table').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
        },
        "order": [[ 3, "desc" ]] 
    });

    $('#brandFilter').on('change', function(){
        table.column(1).search(
            this.value ? '^' + this.value + '$' : '',
            true,
            false
        ).draw();
    });
});
</script>

<?php 
require_once '../includes/footer.php';
?>