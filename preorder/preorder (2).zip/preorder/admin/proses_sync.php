<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    http_response_code(403);
    echo json_encode(['type' => 'gagal', 'message' => 'Akses ditolak.']);
    exit;
}
require_once '../includes/koneksi.php';

header('Content-Type: application/json');

if (!isset($_POST['selected_products']) || empty($_POST['selected_products'])) {
    echo json_encode(['type' => 'gagal', 'message' => 'Tidak ada produk yang dipilih.']);
    exit;
}

$brand_name = "Jubelio";
$jubelio_brand_id = null;
$sql_find_brand = "SELECT id FROM brands WHERE brand_name = ?";
$stmt_find = mysqli_prepare($koneksi, $sql_find_brand);
mysqli_stmt_bind_param($stmt_find, "s", $brand_name);
mysqli_stmt_execute($stmt_find);
$result_brand = mysqli_stmt_get_result($stmt_find);
if ($row = mysqli_fetch_assoc($result_brand)) {
    $jubelio_brand_id = $row['id'];
} else {
    $sql_insert_brand = "INSERT INTO brands (brand_name) VALUES (?)";
    $stmt_insert = mysqli_prepare($koneksi, $sql_insert_brand);
    mysqli_stmt_bind_param($stmt_insert, "s", $brand_name);
    mysqli_stmt_execute($stmt_insert);
    $jubelio_brand_id = mysqli_insert_id($koneksi);
}
mysqli_stmt_close($stmt_find);

$selected_products = $_POST['selected_products'];
$added_count = 0;
$updated_count = 0;

foreach ($selected_products as $product_json) {
    $product = json_decode($product_json, true);
    
    $sku = $product['sku'];
    $price = $product['price'];
    $model_name = $product['name'];
    $jubelio_date_str = $product['jubelio_date'];
    $jubelio_date_formatted = date("Y-m-d H:i:s", strtotime($jubelio_date_str));

    $sql_check = "SELECT id, base_price, model_name FROM products WHERE sku = ?";
    $stmt_check = mysqli_prepare($koneksi, $sql_check);
    mysqli_stmt_bind_param($stmt_check, "s", $sku);
    mysqli_stmt_execute($stmt_check);
    $res_check = mysqli_stmt_get_result($stmt_check);
    
    if ($existing_product = mysqli_fetch_assoc($res_check)) {
        if ($existing_product['base_price'] != $price || $existing_product['model_name'] != $model_name) {
            $sql_update = "UPDATE products SET base_price = ?, model_name = ?, jubelio_created_at = ? WHERE id = ?";
            $stmt_update = mysqli_prepare($koneksi, $sql_update);
            mysqli_stmt_bind_param($stmt_update, "dssi", $price, $model_name, $jubelio_date_formatted, $existing_product['id']);
            mysqli_stmt_execute($stmt_update);
            $updated_count++;
        }
    } else {
        $sql_insert = "INSERT INTO products (brand_id, model_name, sku, base_price, jubelio_created_at) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert = mysqli_prepare($koneksi, $sql_insert);
        mysqli_stmt_bind_param($stmt_insert, "isssd", $jubelio_brand_id, $model_name, $sku, $price, $jubelio_date_formatted);
        mysqli_stmt_execute($stmt_insert);
        $added_count++;
    }
}

$message = "Proses Selesai. Produk Baru: $added_count, Produk Diperbarui: $updated_count.";
$type = 'info'; 

if ($added_count > 0) {
    $type = 'sukses';
} elseif ($updated_count > 0) {
    $type = 'warning';
}

echo json_encode(['type' => $type, 'message' => $message]);
exit;
?>