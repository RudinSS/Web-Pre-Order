<?php
session_start();
require_once 'includes/koneksi.php';

$tipe_login = $_POST['tipe_login'] ?? '';

// =======================================================
// ALUR LOGIN UNTUK ADMIN VIA JUBELIO
// =======================================================
if ($tipe_login === 'admin_jubelio') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // URL ENDPOINT LOGIN YANG SUDAH DIPERBARUI
    $loginEndpoint = 'https://api2.jubelio.com/login';
    $loginData = json_encode(['email' => $email, 'password' => $password]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $loginEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $loginData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $response = json_decode($result, true);

    if ($http_code === 200 && isset($response['token'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $response['userName'];
        $_SESSION['role'] = 'admin';
        $_SESSION['jubelio_token'] = $response['token'];

        header("Location: dashboard.php");
        exit;
    } else {
        header("Location: index.php?pesan=gagal_admin");
        exit;
    }
}
// =======================================================
// ALUR LOGIN UNTUK CUSTOMER (TETAP SAMA)
// =======================================================
elseif ($tipe_login === 'customer') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, username, password, role FROM users WHERE username = ?";
    
    if ($stmt = mysqli_prepare($koneksi, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) == 1) {
                mysqli_stmt_bind_result($stmt, $id, $db_username, $hashed_password, $role);
                
                if (mysqli_stmt_fetch($stmt)) {
                    if (password_verify($password, $hashed_password) && $role === 'customer') {
                        $_SESSION['loggedin'] = true;
                        $_SESSION['user_id'] = $id;
                        $_SESSION['username'] = $db_username;
                        $_SESSION['role'] = $role;
                        
                        header("Location: dashboard.php");
                        exit;
                    }
                }
            }
        }
        mysqli_stmt_close($stmt);
    }
    header("Location: index.php?pesan=gagal_customer");
    exit;
}
else {
    header("Location: index.php");
    exit;
}
?>