<?php 
// Panggil header yang berisi sidebar dan proteksi halaman
require_once 'includes/header.php'; 
?>

<div class="content-box">
    <h2>Selamat Datang!</h2>
    <p>Anda telah berhasil login ke Sistem Pre-Order.</p>
    <p>Silakan gunakan menu navigasi di sebelah kiri untuk mengakses fitur yang tersedia.</p>
</div>

<?php 
// Panggil footer
require_once 'includes/footer.php'; 
?>