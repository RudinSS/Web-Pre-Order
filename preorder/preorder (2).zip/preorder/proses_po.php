<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'customer') {
    header("Location: index.php");
    exit;
}
require_once 'includes/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_SESSION['user_id'];
    $quantities = $_POST['qty'];
    
    unset($_SESSION['po_cart']);

    $ordered_items = [];
    foreach ($quantities as $product_id => $qty) {
        if ($qty > 0) {
            $ordered_items[$product_id] = (int)$qty;
        }
    }

    if (empty($ordered_items)) {
        header("Location: po_baru.php?pesan=kosong");
        exit;
    }

    mysqli_begin_transaction($koneksi);
    try {
        $sql_order = "INSERT INTO pre_orders (customer_id, total_amount, status) VALUES (?, 0, 'pending')";
        $stmt_order = mysqli_prepare($koneksi, $sql_order);
        mysqli_stmt_bind_param($stmt_order, "i", $customer_id);
        mysqli_stmt_execute($stmt_order);
        $order_id = mysqli_insert_id($koneksi);
        mysqli_stmt_close($stmt_order);

        $grand_total = 0;
        
        $sql_item = "INSERT INTO pre_order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        $stmt_item = mysqli_prepare($koneksi, $sql_item);

        foreach ($ordered_items as $product_id => $qty) {
            // Ambil harga produk dari database untuk keamanan
            $sql_price = "SELECT base_price FROM products WHERE id = " . (int)$product_id;
            $res_price = mysqli_query($koneksi, $sql_price);
            $prod_data = mysqli_fetch_assoc($res_price);
            $price = $prod_data['base_price'];

            $grand_total += $qty * $price;

            mysqli_stmt_bind_param($stmt_item, "iiid", $order_id, $product_id, $qty, $price);
            mysqli_stmt_execute($stmt_item);
        }
        mysqli_stmt_close($stmt_item);

        $sql_update_total = "UPDATE pre_orders SET total_amount = ? WHERE id = ?";
        $stmt_update_total = mysqli_prepare($koneksi, $sql_update_total);
        mysqli_stmt_bind_param($stmt_update_total, "di", $grand_total, $order_id);
        mysqli_stmt_execute($stmt_update_total);
        mysqli_stmt_close($stmt_update_total);

        mysqli_commit($koneksi);
        header("Location: pesanan_berhasil.php?order_id=" . $order_id);
        exit;
    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        header("Location: po_baru.php?pesan=gagal"); // Matikan redirect sementara
        //die("TERJADI ERROR DATABASE: " . $e->getMessage()); // Tampilkan pesan error yang asli
        exit;
    }
}
?>