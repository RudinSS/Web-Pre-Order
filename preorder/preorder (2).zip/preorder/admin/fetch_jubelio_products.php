<?php
session_start(); // 1. Mulai sesi untuk membaca data

// Pastikan hanya admin yang login dan punya token yang bisa akses
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin' || !isset($_SESSION['jubelio_token'])) {
    header('Content-Type: application/json');
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Akses ditolak.']);
    exit;
}

// 2. Ambil data yang diperlukan dari sesi
$jubelioApiToken = $_SESSION['jubelio_token'];

// 3. SEGERA TUTUP SESI DAN LEPAS KUNCI
session_write_close();

// 4. Lakukan panggilan API yang lama SETELAH sesi ditutup
$endpoint = 'https://api2.jubelio.com/inventory/items/'; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $endpoint);
// Opsi timeout untuk mencegah skrip berjalan terlalu lama
curl_setopt($ch, CURLOPT_TIMEOUT, 60); // Timeout setelah 60 detik
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$headers = ['Authorization: Bearer ' . $jubelioApiToken];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$api_result = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$data = json_decode($api_result, true);

// Atur header output sebagai JSON
header('Content-Type: application/json');

if ($http_code === 200 && !empty($data['data'])) {
    echo json_encode($data['data']);
} else {
    http_response_code($http_code > 0 ? $http_code : 500);
    echo json_encode(['error' => 'Gagal mengambil data dari Jubelio.', 'details' => $data]);
}
exit;