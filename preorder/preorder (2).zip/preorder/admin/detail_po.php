<?php 
require_once '../includes/header.php'; 
require_once '../includes/koneksi.php';

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($order_id === 0) {
    die("ID Pesanan tidak valid.");
}

// Ambil data pesanan utama
$sql_order = "SELECT po.*, u.full_name, u.username FROM pre_orders po JOIN users u ON po.customer_id = u.id WHERE po.id = ?";
$stmt_order = mysqli_prepare($koneksi, $sql_order);
mysqli_stmt_bind_param($stmt_order, "i", $order_id);
mysqli_stmt_execute($stmt_order);
$result_order = mysqli_stmt_get_result($stmt_order);
$order = mysqli_fetch_assoc($result_order);

if (!$order) {
    die("Pesanan tidak ditemukan.");
}
?>

<div class="content-box">
    <a href="admin_po_masuk.php">&larr; Kembali ke Daftar PO</a>
    <h1 style="margin-top: 20px;">Detail Pesanan #<?php echo $order['id']; ?></h1>

    <div style="margin-bottom: 20px;">
        <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['full_name']); ?> (<?php echo htmlspecialchars($order['username']); ?>)</p>
        <p><strong>Tanggal Pesan:</strong> <?php echo date("d M Y, H:i", strtotime($order['order_date'])); ?></p>
        <p><strong>Status:</strong> <span style="font-weight: bold; text-transform: capitalize;"><?php echo htmlspecialchars($order['status']); ?></span></p>
        <p><strong>Total Pesanan:</strong> <strong style="color: #28a745;">Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></strong></p>
    </div>

    <h3>Rincian Item</h3>
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="border: 1px solid #ddd; padding: 8px;">SKU</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Nama Produk</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Harga Satuan</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Jumlah</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql_items = "SELECT oi.*, p.sku, p.model_name
                          FROM pre_order_items oi 
                          JOIN products p ON oi.product_id = p.id
                          WHERE oi.order_id = ?";
            $stmt_items = mysqli_prepare($koneksi, $sql_items);
            mysqli_stmt_bind_param($stmt_items, "i", $order_id);
            mysqli_stmt_execute($stmt_items);
            $result_items = mysqli_stmt_get_result($stmt_items);

            while ($item = mysqli_fetch_assoc($result_items)): 
                $subtotal = $item['quantity'] * $item['price'];
            ?>
                <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;"><?php echo htmlspecialchars($item['sku']); ?></td>
                    <td style="border: 1px solid #ddd; padding: 8px;"><?php echo htmlspecialchars($item['model_name']); ?></td>
                    <td style="border: 1px solid #ddd; padding: 8px;">Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                    <td style="border: 1px solid #ddd; padding: 8px;"><?php echo $item['quantity']; ?></td>
                    <td style="border: 1px solid #ddd; padding: 8px;">Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php 
require_once '../includes/footer.php';
?>