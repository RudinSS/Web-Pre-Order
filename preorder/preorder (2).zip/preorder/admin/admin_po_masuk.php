<?php 
require_once '../includes/header.php'; 
require_once '../includes/koneksi.php'; 
?>

<div class="content-box">
    <h1>Daftar Pre-Order Masuk</h1>
    <p>Di bawah ini adalah daftar semua pesanan yang telah dibuat oleh customer.</p>

    <?php if (isset($_GET['status_update']) && $_GET['status_update'] == 'sukses'): ?>
        <div style="padding: 15px; margin-bottom: 20px; border-radius: 5px; background-color: #d4edda; color: #155724;">
            Status pesanan berhasil diperbarui.
        </div>
    <?php endif; ?>

    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="border: 1px solid #ddd; padding: 8px;">ID PO</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Nama Customer</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Tanggal Pesan</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Total</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Status</th>
                <th style="border: 1px solid #ddd; padding: 8px;">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT po.*, u.full_name 
                    FROM pre_orders po 
                    JOIN users u ON po.customer_id = u.id 
                    ORDER BY po.order_date DESC";
            $result = mysqli_query($koneksi, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>#" . $row['id'] . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($row['full_name']) . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . date("d M Y, H:i", strtotime($row['order_date'])) . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>Rp " . number_format($row['total_amount'], 0, ',', '.') . "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'>";
                    // Form kecil untuk update status
                    echo "<form action='proses_update_status.php' method='POST' style='margin:0;'>";
                    echo "<input type='hidden' name='order_id' value='" . $row['id'] . "'>";
                    echo "<select name='status' onchange='this.form.submit()' style='padding: 5px;'>";
                    $statuses = ['pending', 'confirmed', 'completed', 'canceled'];
                    foreach ($statuses as $status) {
                        $selected = ($row['status'] == $status) ? 'selected' : '';
                        echo "<option value='$status' $selected>" . ucfirst($status) . "</option>";
                    }
                    echo "</select>";
                    echo "</form>";
                    echo "</td>";
                    echo "<td style='border: 1px solid #ddd; padding: 8px;'><a href='detail_po.php?id=" . $row['id'] . "'>Lihat Detail</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='border: 1px solid #ddd; padding: 8px; text-align:center;'>Belum ada pesanan masuk.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php 
require_once '../includes/footer.php';
?>